module.exports = {
  plugins: {
    tailwindcss: {},
    cssnano: {},
  },
};
